Midtown Madness Vehicle Creation Kit Guide and Toolset
=======

Inside you will find all the tools you need to create custom cars for Midton Madness without using 3DS Max or other expensive tools.

=======
HOW TO USE
=======
First, uzip the contents of the MM_VCK_Toolset.zip to the location of your choice.

Here is a rundown of whats inside this toolset.

\MM_VCK_Toolset\
	MMVCKGT.doc -- The guide to creating cars
	Readme.txt -- The file your reading right now
	\VCK\
	    vck.zip -- The official Vehicle Creation Kit from Microsoft
	\Import\
	    vpredcar_s.3ds -- A file used in the creation process, explained in the guide
	\Zmodeler\
	    zmodeler_v107.exe -- The modeling program you will use
	\IrfanView\
	    IrfanView -- A link to an image viewing/conversion program you will use
	\Examples\
	    \vpcolorado\ -- An example car I made


Start by opening up the MMVCKGT.doc file and start reading!  Hopefully it is easy to understand.

I've included the first car I made that worked, a Chevy Colorado. You can use it as a reference or test if you'd like.


Oh, yea, if you screw up Midtown Madness, you computer, your brain, or anything else, Its not my fault - Use at your own risk!  Of course, nothing should happen though.